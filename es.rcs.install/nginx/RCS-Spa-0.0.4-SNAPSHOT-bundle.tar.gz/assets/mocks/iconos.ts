export class Iconos {
	applicationIcons = {
		'tfm.app.adm': 'settings',
		'tfm.app.bus': 'search',
		'tfm.app.the': 'account_tree',
		'tfm.app.dic': '',
		'tfm.app.cor': 'library_books',
	};

	moduleIcons = {
		'tfm.app.adm.usr': 'person',
		'tfm.app.adm.grp': 'group',
		'tfm.app.adm.app': 'view_comfy',
		'tfm.app.adm.mod': 'view_module',
		'tfm.app.adm.fun': 'view_list',
		'tfm.app.adm.rol': 'supervised_user_circle',
		'tfm.app.adm.aut': 'security',
		'tfm.app.bus.art': '',
		'tfm.app.the.des': '',
		'tfm.app.the.cua': '',
		'tfm.app.dic.voc': 'view_list',
		'tfm.app.cor.dat': '',
		'tfm.app.cor.mod': '',
	};

	functionIcons = {
		'tfm.app.adm': 'settings',
	};

}
